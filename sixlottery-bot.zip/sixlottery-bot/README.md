# 6Lottery Telegram Bot

Single-file Node.js bot (Node 20+, no npm packages).

## Setup
1. Get a token from @BotFather in Telegram.
2. Open `bot.js` and replace the first line value:
   `const BOT_TOKEN = "PASTE_BOT_TOKEN_HERE";`
   (or skip editing and run `BOT_TOKEN=your_token node bot.js`)
3. Run:
   ```
   node bot.js
   ```
4. In Telegram send `/start`.

## Usage
- `Login ACC` -> phone, then password (or send `Login` / phone / password on 3 lines).
- `AI Agent` (locked until login) -> `Auto Run`, `Stop`, `Back`.
- `Auto Run` checks the round every 5 seconds. With `DRY_RUN = true` it only sends preview messages and never bets.

## Notes
- Keep `DRY_RUN = true` until you've verified the API fields.
- Login/bet field names and signatures in `apiLogin` / `apiBet` are starter guesses; adjust them to the real API.
- Your server IP may need whitelisting by the API provider.
