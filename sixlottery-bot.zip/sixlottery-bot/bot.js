// ============================================================
//  6Lottery Telegram Bot  -  single file, Node 20+, zero deps
// ============================================================
const BOT_TOKEN = "PASTE_BOT_TOKEN_HERE";
const DRY_RUN = true; // true = preview only, NO real bets. Set false only when you are sure.

const LOGIN_URL   = "https://6lotteryapi.com/api/webapi/Login";
const BALANCE_URL = "https://6lotteryapi.com/api/webapi/GetUserInfo";
const ISSUE_URL   = "https://6lotteryapi.com/api/webapi/GetGameIssue";
const BET_URL     = "https://6lotteryapi.com/api/webapi/GameBetting";

// ---------------- Settings ----------------
const TYPE_ID = 30;
const LOOP_MS = 5000;
const BET_AMOUNT = 10;
const REQUEST_TIMEOUT_MS = 15000;
// ------------------------------------------

const TOKEN = process.env.BOT_TOKEN || BOT_TOKEN;
const TG = `https://api.telegram.org/bot${TOKEN}`;

if (!TOKEN || TOKEN === "PASTE_BOT_TOKEN_HERE") {
  console.error('Set BOT_TOKEN at the top of bot.js (or run: BOT_TOKEN=xxx node bot.js)');
  process.exit(1);
}

// ---------------- Per-user state ----------------
const sessions = new Map();
function getSession(chatId) {
  if (!sessions.has(chatId)) {
    sessions.set(chatId, {
      chatId,
      step: "idle", // idle | phone | password
      phone: "",
      password: "",
      token: "",
      balance: null,
      isLoggedIn: false,
      isRunning: false,
      intervalId: null,
      busy: false,
      lastIssue: "",
      inAgentMenu: false,
    });
  }
  return sessions.get(chatId);
}

// ---------------- Keyboards ----------------
const mainKeyboard = {
  keyboard: [[{ text: "Login ACC" }, { text: "AI Agent" }]],
  resize_keyboard: true,
};
const agentKeyboard = {
  keyboard: [[{ text: "Auto Run" }, { text: "Stop" }], [{ text: "Back" }]],
  resize_keyboard: true,
};

// ---------------- Telegram helpers ----------------
async function tg(method, payload) {
  try {
    const res = await fetch(`${TG}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
    return await res.json();
  } catch (e) {
    console.error(`[tg:${method}]`, e.message);
    return null;
  }
}
const send = (chatId, text, keyboard) =>
  tg("sendMessage", { chat_id: chatId, text, ...(keyboard ? { reply_markup: keyboard } : {}) });

// ---------------- 6Lottery API ----------------
function randomStr() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

async function apiPost(url, body, token) {
  try {
    const headers = { "Content-Type": "application/json;charset=UTF-8", Accept: "application/json" };
    if (token) headers.Authorization = `Bearer ${token}`;
    const res = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
    const text = await res.text();
    let json;
    try { json = JSON.parse(text); }
    catch { return { ok: false, error: `HTTP ${res.status}: non-JSON response (${text.slice(0, 120)})` }; }
    if (!res.ok) return { ok: false, error: `HTTP ${res.status}: ${json.msg || json.message || "request failed"}`, json };
    return { ok: true, json };
  } catch (e) {
    return { ok: false, error: `Network error: ${e.message}` };
  }
}

const isApiSuccess = (j) =>
  j && (j.code === 0 || j.code === 200 || String(j.msg || "").toLowerCase() === "succeed");

// NOTE: adjust field names / add signature to match the real API once you have its docs.
async function apiLogin(phone, password) {
  const r = await apiPost(LOGIN_URL, {
    username: phone,
    pwd: password,
    phonetype: -1,
    logintype: "mobile",
    language: 0,
    random: randomStr(),
    timestamp: Math.floor(Date.now() / 1000),
  });
  if (!r.ok) return { success: false, error: r.error };
  const j = r.json;
  if (!isApiSuccess(j)) return { success: false, error: j.msg || j.message || "Login failed (wrong phone/password?)" };
  const d = j.data || {};
  const token = d.token || d.tokenHeader || j.token || "";
  if (!token) return { success: false, error: "Login response had no token/session." };
  return { success: true, token };
}

async function apiBalance(token) {
  const r = await apiPost(BALANCE_URL, {
    language: 0, random: randomStr(), timestamp: Math.floor(Date.now() / 1000),
  }, token);
  if (!r.ok || !isApiSuccess(r.json)) return null;
  const d = r.json.data || {};
  return d.amount ?? d.balance ?? null;
}

async function apiGetIssue(token) {
  const r = await apiPost(ISSUE_URL, {
    typeId: TYPE_ID, language: 0, random: randomStr(), timestamp: Math.floor(Date.now() / 1000),
  }, token);
  if (!r.ok) return { success: false, error: r.error };
  if (!isApiSuccess(r.json)) return { success: false, error: r.json.msg || "GetGameIssue failed" };
  const d = r.json.data || {};
  const issue = d.issueNumber || d.issuenumber || "";
  if (!issue) return { success: false, error: "No issue number in response" };
  return { success: true, issue: String(issue), raw: d };
}

async function apiBet(token, issue, side) {
  return apiPost(BET_URL, {
    typeId: TYPE_ID,
    issuenumber: issue,
    amount: BET_AMOUNT,
    betCount: 1,
    gameType: 2,
    selectType: side === "Big" ? 13 : 14, // adjust to the real API codes
    language: 0,
    random: randomStr(),
    timestamp: Math.floor(Date.now() / 1000),
  }, token);
}

// ---------------- AI Agent cycle ----------------
// Placeholder "strategy": random Big/Small. Replace with your own logic.
function pickSide() {
  return Math.random() < 0.5 ? "Big" : "Small";
}

async function runAiAgentCycle(session) {
  const { chatId } = session;
  const info = await apiGetIssue(session.token);
  if (!info.success) {
    console.log(`[${chatId}] issue error: ${info.error}`);
    return;
  }
  if (info.issue === session.lastIssue) return; // act once per round
  session.lastIssue = info.issue;

  const side = pickSide();
  if (DRY_RUN) {
    console.log(`[${chatId}] DRY_RUN issue ${info.issue} -> ${side} x ${BET_AMOUNT}`);
    await send(chatId, `🧪 DRY RUN (no real bet)\nRound: ${info.issue}\nPick: ${side}\nAmount: ${BET_AMOUNT}`);
    return;
  }

  const r = await apiBet(session.token, info.issue, side);
  if (r.ok && isApiSuccess(r.json)) {
    const bal = await apiBalance(session.token);
    if (bal !== null) session.balance = bal;
    await send(chatId, `✅ Bet placed\nRound: ${info.issue}\nPick: ${side}\nAmount: ${BET_AMOUNT}${bal !== null ? `\nBalance: ${bal}` : ""}`);
  } else {
    await send(chatId, `❌ Bet failed: ${r.error || r.json?.msg || "unknown error"}`);
  }
}

function startLoop(session) {
  if (session.intervalId) clearInterval(session.intervalId);
  session.isRunning = true;
  session.lastIssue = "";
  session.intervalId = setInterval(async () => {
    if (session.busy || !session.isRunning) return;
    session.busy = true;
    try {
      await runAiAgentCycle(session);
    } catch (e) {
      console.error(`[${session.chatId}] cycle error:`, e);
    } finally {
      session.busy = false;
    }
  }, LOOP_MS);
}

function stopLoop(session) {
  if (session.intervalId) clearInterval(session.intervalId);
  session.intervalId = null;
  session.isRunning = false;
}

// ---------------- Login flow ----------------
async function doLogin(session, phone, password) {
  const { chatId } = session;
  session.step = "idle";
  await send(chatId, "⏳ Logging in...");
  const res = await apiLogin(phone, password);
  if (res.success) {
    session.phone = phone;
    session.password = password;
    session.token = res.token;
    session.isLoggedIn = true;
    const bal = await apiBalance(res.token);
    if (bal !== null) session.balance = bal;
    await send(chatId, "Login Successfully!" + (session.balance !== null ? `\nBalance: ${session.balance}` : ""), mainKeyboard);
  } else {
    session.isLoggedIn = false;
    session.token = "";
    await send(chatId, `❌ Login failed: ${res.error}`, mainKeyboard);
  }
}

// ---------------- Message handler ----------------
async function handleMessage(msg) {
  const chatId = msg.chat?.id;
  const text = (msg.text || "").trim();
  if (!chatId || !text) return;
  const session = getSession(chatId);

  // Start
  if (text === "/start" || text === "Start") {
    session.step = "idle";
    session.inAgentMenu = false;
    return send(chatId,
      `👋 Welcome!\n\nUse "Login ACC" to sign in, then open "AI Agent".\nMode: ${DRY_RUN ? "DRY RUN (safe preview)" : "LIVE"}`,
      mainKeyboard);
  }

  // One-message login: "Login\nPhone\nPassword"
  const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
  if (lines.length >= 3 && /^login(\s*acc)?$/i.test(lines[0])) {
    tg("deleteMessage", { chat_id: chatId, message_id: msg.message_id });
    return doLogin(session, lines[1], lines[2]);
  }

  // Menu buttons
  if (text === "Login ACC") {
    session.step = "phone";
    return send(chatId, "📱 Send your Phone Number:", { remove_keyboard: true });
  }

  if (text === "AI Agent") {
    if (!session.isLoggedIn) {
      return send(chatId, "🔒 AI Agent is locked. Please complete Login ACC first.", mainKeyboard);
    }
    session.inAgentMenu = true;
    return send(chatId,
      `🤖 AI Agent\nStatus: ${session.isRunning ? "Running ▶️" : "Stopped ⏹"}\nMode: ${DRY_RUN ? "DRY RUN" : "LIVE"}`,
      agentKeyboard);
  }

  if (text === "Auto Run") {
    if (!session.isLoggedIn) return send(chatId, "🔒 Please complete Login ACC first.", mainKeyboard);
    if (session.isRunning) return send(chatId, "▶️ Auto Run is already running.", agentKeyboard);
    startLoop(session);
    return send(chatId,
      DRY_RUN
        ? "▶️ Auto Run started (DRY RUN - previews only, no real bets)."
        : "▶️ Auto Run started (LIVE).",
      agentKeyboard);
  }

  if (text === "Stop") {
    const was = session.isRunning;
    stopLoop(session);
    return send(chatId, was ? "⏹ Auto Run stopped." : "⏹ Auto Run is not running.", agentKeyboard);
  }

  if (text === "Back") {
    session.inAgentMenu = false; // does NOT stop a running loop
    return send(chatId,
      `🏠 Main menu${session.isRunning ? "\n(Auto Run is still running)" : ""}`,
      mainKeyboard);
  }

  // Step-by-step login
  if (session.step === "phone") {
    session.phone = text;
    session.step = "password";
    return send(chatId, "🔑 Now send your Password:");
  }
  if (session.step === "password") {
    tg("deleteMessage", { chat_id: chatId, message_id: msg.message_id });
    return doLogin(session, session.phone, text);
  }

  return send(chatId, "Please use the buttons below.", session.inAgentMenu ? agentKeyboard : mainKeyboard);
}

// ---------------- Long polling ----------------
let offset = 0;
async function poll() {
  while (true) {
    try {
      const res = await fetch(`${TG}/getUpdates`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ offset, timeout: 30, allowed_updates: ["message"] }),
        signal: AbortSignal.timeout(45000),
      });
      const data = await res.json();
      if (!data.ok) {
        console.error("[poll] Telegram error:", data.description);
        await new Promise((r) => setTimeout(r, 5000));
        continue;
      }
      for (const u of data.result) {
        offset = u.update_id + 1;
        if (u.message) {
          handleMessage(u.message).catch((e) => console.error("[handler]", e));
        }
      }
    } catch (e) {
      console.error("[poll]", e.message);
      await new Promise((r) => setTimeout(r, 3000));
    }
  }
}

process.on("unhandledRejection", (e) => console.error("[unhandledRejection]", e));
process.on("uncaughtException", (e) => console.error("[uncaughtException]", e));

console.log(`Bot started. DRY_RUN=${DRY_RUN}`);
poll();
